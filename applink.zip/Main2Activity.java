package ani.com.ecommerceapp3;
import com.twilio.Twilio;
import com.twilio.rest.api.v2010.account.Message;
import com.twilio.rest.api.v2010.account.MessageCreator;
import com.twilio.type.PhoneNumber;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.support.annotation.IntegerRes;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import com.firebase.client.Firebase;

public class Main2Activity extends AppCompatActivity {
    private Firebase ref2;
    private Button btn2;
    public EditText edt1;
    public EditText edt2;
    public EditText edt3;
    private Button btn5;
    private CheckBox chk1;
    private CheckBox chk2;
    private CheckBox chk3;
    public int totalamount = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        Firebase.setAndroidContext(getApplication());
        ref2 = new Firebase("https://ecommerceapp32.firebaseio.com/");
        btn2 = (Button) findViewById(R.id.button2);
        chk1 = (CheckBox) findViewById(R.id.checkBox);
        chk2 = (CheckBox) findViewById(R.id.checkBox2);
        chk3 = (CheckBox) findViewById(R.id.checkBox3);
        edt1 = (EditText) findViewById(R.id.editText10);
        edt2 = (EditText) findViewById(R.id.editText7);
        edt3 = (EditText) findViewById(R.id.editText8);
        btn5 = (Button) findViewById(R.id.btn5);
        /*chk1.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                edt1=(EditText)findViewById(R.id.editText6);
                chk1=(CheckBox)findViewById(R.id.checkBox);
                //is chkIos checked?
                if (((CheckBox) v).isChecked()) {
                    int a= Integer.parseInt(edt1.getText().toString());
                    totalamount=totalamount+a*100;


                }
            }});
        chk2.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                chk2=(CheckBox)findViewById(R.id.checkBox2);
                edt2=(EditText)findViewById(R.id.editText8);
                //is chkIos checked?
                if (((CheckBox) v).isChecked()) {

                    int b= Integer.parseInt(edt2.getText().toString());
                    totalamount=totalamount+b*30000;



                }
            }});
        chk3.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                //is chkIos checked?
                if (((CheckBox) v).isChecked()) {
                    int c= Integer.parseInt(edt2.getText().toString());
                    totalamount=totalamount+c*5000;



                }
            }
        });*/
        btn5.setOnClickListener(new View.OnClickListener() {

            //Run when button is clicked
            @Override
            public void onClick(View v) {
                String a1=edt1.getText().toString();
                String a2=edt2.getText().toString();
                String a3=edt3.getText().toString();
                if(a1.matches("")){
                    a1="0";
                }
                if(a2.matches("")){
                    a2="0";
                }
                if(a3.matches("")){
                    a3="0";
                }


                Intent intent2=new Intent(Main2Activity.this, Main3Activity.class);
                intent2.putExtra("bucketno", a1);
                intent2.putExtra("bucketno1", a2);
                intent2.putExtra("bucketno2", a3);



                startActivity(intent2);

            }


        });
        btn2.setOnClickListener(new View.OnClickListener() {

            //Run when button is clicked
            @Override
            public void onClick(View v) {
                String a1 = edt1.getText().toString();
                String a2 = edt2.getText().toString();
                String a3 = edt3.getText().toString();
                int a, b, c;
                if (a1.matches("")) {
                    a = 0;
                } else {
                    a = Integer.parseInt(edt1.getText().toString());
                    if(a<0){
                        Toast.makeText(Main2Activity.this, "ENTER QUANTITY GREATOR THAN 0", Toast.LENGTH_SHORT).show();
                    }
                }
                if (a2.matches("")) {
                    b = 0;
                } else {

                    b = Integer.parseInt(edt2.getText().toString());
                    if(b<0) {
                        Toast.makeText(Main2Activity.this, "ENTER QUANTITY GREATOR THAN 0", Toast.LENGTH_SHORT).show();
                    }
                }
                if (a3.matches("")) {
                    c = 0;
                } else {
                    c = Integer.parseInt(edt3.getText().toString());
                    if(b<0) {
                        Toast.makeText(Main2Activity.this, "ENTER QUANTITY GREATOR THAN 0", Toast.LENGTH_SHORT).show();
                    }    }


                StringBuffer result = new StringBuffer();
                result.append("SUNGLASSES PURCHASED : ").append(chk1.isChecked());
                result.append("\nLAPTOP PURCHASED: ").append(chk2.isChecked());
                result.append("\nWATCH PURCHASED :").append(chk3.isChecked());


                if (chk1.isChecked()) {
                    totalamount = totalamount + a * 100;
                    Firebase mrefchild3 = ref2.child("Item name");
                    mrefchild3.setValue("sunglass");
                    Firebase mrefchild4 = ref2.child("Item totalcost cost");
                    mrefchild4.setValue(a * 100);

                } else {
                    Firebase mrefchild3 = ref2.child("Item name");
                    mrefchild3.setValue("sunglass");
                    Firebase mrefchild4 = ref2.child("Item totalcost cost");
                    mrefchild4.setValue(0);

                }
                if (chk2.isChecked()) {
                    totalamount = totalamount + b * 30000;
                    Firebase mrefchild5 = ref2.child("Item name2");
                    mrefchild5.setValue("laptop");
                    Firebase mrefchild6 = ref2.child("Item totalcost cost2");
                    mrefchild6.setValue(b * 30000);
                } else {
                    Firebase mrefchild5 = ref2.child("Item name2");
                    mrefchild5.setValue("laptop");
                    Firebase mrefchild6 = ref2.child("Item totalcost cost2");
                    mrefchild6.setValue(0);
                }
                if (chk3.isChecked()) {
                    totalamount = totalamount + c * 5000;
                    Firebase mrefchild7 = ref2.child("Item name3");
                    mrefchild7.setValue("watch");
                    Firebase mrefchild8 = ref2.child("Item totalcost cost3");
                    mrefchild8.setValue(c * 5000);
                } else {
                    Firebase mrefchild7 = ref2.child("Item name3");
                    mrefchild7.setValue("watch");
                    Firebase mrefchild8 = ref2.child("Item totalcost cost3");
                    mrefchild8.setValue(0);
                }
                result.append(totalamount);
                Firebase mrefchild = ref2.child("purchase amount");
                mrefchild.setValue(totalamount);
                Firebase mrefchild2 = ref2.child("total items");
                mrefchild2.setValue(a + b + c);


                Context context = getApplicationContext();
                CharSequence text = "Hello toast!";
                int duration = Toast.LENGTH_LONG;

                Toast toast = Toast.makeText(context, result, duration);
                toast.show();

                //      launchactivity1();




            }
        });
    }

    public void obrBez1(View view) {
        Intent intent1 = new Intent(Main2Activity.this, Main3Activity.class);
        startActivity(intent1);
        finish();
    }

}



    //public void launchactivity1(){
        //startActivity(new Intent(this, Main3Activity.class));



















