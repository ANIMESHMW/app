package ani.com.ecommerceapp3;


import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import javax.activation.*;
import com.firebase.client.Firebase;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Main3Activity extends AppCompatActivity {

    private TextView txt1;
    private EditText email;
   // private EditText edt1;private EditText edt2;private EditText edt3;
    Firebase get;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        txt1=(TextView)findViewById(R.id.txt8);
        email=(EditText)findViewById(R.id.email);
        Firebase.setAndroidContext(getApplication());
        Intent intent = getIntent();
        String value = getIntent().getExtras().getString("bucketno");
        String value2= intent.getExtras().getString("bucketno1");
        String value3 = intent.getExtras().getString("bucketno2");


        //edt1=(EditText)findViewById(R.id.editText10);
        //edt2=(EditText)findViewById(R.id.editText7);
        //edt3=(EditText)findViewById(R.id.editText8);
        //String a1 = edt1.getText().toString();
        //String a2 = edt2.getText().toString();
        //String a3 = edt3.getText().toString();
        //
        // txt1.append(resul);
         //   get=new Firebase("https://ecommerceapp32.firebaseio.com/");
        //Firebase get1=get.child("purchase amount");
       /// final FirebaseDatabase database = FirebaseDatabase.getInstance();
       // DatabaseReference ref = database.getReference("https://ecommerceapp32.firebaseio.com/purchase amount");

        int a=Integer.parseInt(value);
        int b=Integer.parseInt(value2);
        int c=Integer.parseInt(value3);
        int d=a+b+c;
         a=a*100;
        b=b*30000;
        c=c*5000;
         int e=a+b+c;
        StringBuffer result = new StringBuffer();
        result.append("SUNGLASSES PURCHASED : ").append(a);
        result.append("\nLAPTOP PURCHASED: ").append(b);
        result.append("\nWATCH PURCHASED :").append(c);
    result.append("\nTOTAL CART VALUE").append(e);
        result.append("\nTOTAL ITEMS:").append(d);
        result.append("\n");
        txt1.append(result);
        txt1.append("SUNGLASSES->");
        txt1.append(value);
        //txt1.append(a);
        txt1.append("\n");


        txt1.append("LAPTOP->");
        txt1.append(value2);txt1.append("\t");
//txt1.append(b);
txt1.append("\n");
        txt1.append("WATCH->");
        txt1.append(value3);
        txt1.append("\n");




    }


    public void send(View view) {
      String email1=email.getText().toString();


        if(email1.isEmpty()){
            Toast.makeText(Main3Activity.this, "PROVIDE EMAILID", Toast.LENGTH_SHORT).show();
        }
        Firebase son=new Firebase("https://ecommerceapp32.firebaseio.com/");
        Firebase sn1=son.child("EMAILID");
        sn1.setValue(email1);
        Toast.makeText(Main3Activity.this, "YOUR ORDER IS DUE AND YOU WILL GET NOGTIFICATION AFTER CONFIRMATION at  "+email1, Toast.LENGTH_SHORT).show();





        // TODO Auto-generated method stub

           /* try {
                GMailSender sender = new GMailSender("username@gmail.com", "password");


                sender.sendMail("This is Subject",
                        "This is Body",
                        "user@gmail.com",
                        "user@yahoo.com");
            } catch (Exception e) {
                Log.e("SendMail", e.getMessage(), e);
            }


    };}*/

        //Get properties object


    }}