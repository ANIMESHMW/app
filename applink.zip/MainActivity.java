package ani.com.ecommerceapp3;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.view.Menu;
import android.view.View;
import android.widget.Toast;

import com.firebase.client.Firebase;

public class MainActivity extends AppCompatActivity {
    public Firebase re;
    private Button btn1;
    private EditText edt1;
    private EditText edt2;
    private Button btn2;
    public EditText edt11;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Firebase.setAndroidContext(this);
        re = new Firebase("https://ecommerceapp32.firebaseio.com/");


        //btn2 = (Button) findViewById(R.id.button3);
        btn1 = (Button) findViewById(R.id.adddata);
        edt1 = (EditText) findViewById(R.id.editText);
        edt2 = (EditText) findViewById(R.id.editText3);
        edt11=(EditText)findViewById(R.id.mob);

        btn1.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                final String email = edt1.getText().toString();
                final String password = edt2.getText().toString();
              //  final String mob=edt11.getText().toString();
                //int l=mob.length();

                    //final String mob1=edt11.getText().toString();
                    Firebase refchild = re.child("Username");
                    refchild.setValue(email);
                    Firebase refchild1 = re.child("password");
                    refchild1.setValue(password);
                   // Firebase refchild9 = re.child("Mobile no.");
                    //refchild9.setValue(mob);
                    Toast.makeText(MainActivity.this, "DATABASE UPDATED", Toast.LENGTH_SHORT).show();

                //else{
                  //  Toast.makeText(MainActivity.this, "ENTER MOBILE NO.OF 10 DIGITS", Toast.LENGTH_SHORT).show();
                //}

                //launchActivity();
                ///startActivity(new Intent(MainActivity.this,Main2Activity.class));


            }
        });}

    public void obrBez(View view) {
        Intent intent = new Intent(this, Main2Activity.class);
        startActivity(intent);
        //System.out.println("ok");           // It will not even print out "ok"
    }


}









